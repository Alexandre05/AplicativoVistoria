package com.vistoriapatrimonialmanoelviana.data
// aqui é o nó do firebase
const val NODE_AUTHORS = "patrimonio"