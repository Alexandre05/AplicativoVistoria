package com.vistoriapatrimonialmanoelviana.ui

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.widget.ListView
import android.widget.SearchView
import com.vistoriapatrimonialmanoelviana.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
val busca=findViewById<SearchView>(R.id.busca)


    }



    }



